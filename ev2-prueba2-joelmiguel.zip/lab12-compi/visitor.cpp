#include <iostream>
#include "ast.h"
#include "visitor.h"
#include <unordered_map>
using namespace std;

static unordered_map<string,int> memoria;
int BinaryExp::accept(Visitor* visitor) { return visitor->visit(this); }
int NumberExp::accept(Visitor* visitor) { return visitor->visit(this); }
int IdExp::accept(Visitor* visitor) { return visitor->visit(this); }
int AssignStm::accept(Visitor* visitor) { visitor->visit(this); return 0; }
int PrintStm::accept(Visitor* visitor) { visitor->visit(this); return 0; }
int IfStm::accept(Visitor* visitor) { visitor->visit(this); return 0; }
int WhileStm::accept(Visitor* visitor) { visitor->visit(this); return 0; }
int PrintVisitor::visit(BinaryExp* exp) {
    exp->left->accept(this);
    cout << ' ' << Exp::binopToChar(exp->op) << ' ';
    exp->right->accept(this);
    return 0;
}
int PrintVisitor::visit(NumberExp* exp) { cout << exp->value; return 0; }
int PrintVisitor::visit(IdExp* exp) { cout << exp->value; return 0; }
void PrintVisitor::visit(AssignStm* stm) { cout << stm->id << " = "; stm->e->accept(this); cout << ";"; }
void PrintVisitor::visit(PrintStm* stm) { cout << "print("; stm->e->accept(this); cout << ");"; }
void PrintVisitor::visit(IfStm* stm) {
    cout << "if ("; if (stm->condicion) stm->condicion->accept(this); cout << ") then\n";
    if (stm->thenBody) for (auto s: stm->thenBody->slist) { s->accept(this); cout << "\n"; }
    if (stm->elseBody) { cout << "else\n"; for (auto s: stm->elseBody->slist) { s->accept(this); cout << "\n"; } }
    cout << "endif\n";
}
void PrintVisitor::visit(WhileStm* stm) {
    cout << "while ("; if (stm->condicion) stm->condicion->accept(this); cout << ") do\n";
    if (stm->body) for (auto s: stm->body->slist) { s->accept(this); cout << "\n"; }
    cout << "endwhile\n";
}
void PrintVisitor::imprimir(Program* program) {
    for (auto v: program->vlist) {
        cout << "var " << v->type << " "; bool first=true; for (auto id: v->ids) { if(!first) cout << ","; cout<<id; first=false;} cout<<";\n";
    }
    for (auto s: program->slist) { s->accept(this); cout << "\n"; }
}

 
int EVALVisitor::visit(BinaryExp* exp) {
    int v1 = exp->left->accept(this);
    int v2 = exp->right->accept(this);
    switch (exp->op) {
        case PLUS_OP: return v1 + v2;
        case MINUS_OP: return v1 - v2;
        case MUL_OP: return v1 * v2;
        case DIV_OP: if (v2!=0) return v1 / v2; else { cout<<"Error: division por cero\n"; return 0; }
    case LE_OP: return (v1 < v2) ? 1 : 0;
    case GT_OP: return (v1 > v2) ? 1 : 0;
    case EQ_OP: return (v1 == v2) ? 1 : 0;
        default: cout<<"Operador desconocido\n"; return 0;
    }
}
int EVALVisitor::visit(NumberExp* exp) { return exp->value; }
int EVALVisitor::visit(IdExp* exp) { return memoria[exp->value]; }
void EVALVisitor::visit(IfStm* stm) {
    int cond = stm->condicion->accept(this);
    if (cond) { if (stm->thenBody) for (auto s: stm->thenBody->slist) s->accept(this); }
    else { if (stm->elseBody) for (auto s: stm->elseBody->slist) s->accept(this); }
}
void EVALVisitor::visit(WhileStm* stm) {
    while (stm->condicion->accept(this)) { if (stm->body) for (auto s: stm->body->slist) s->accept(this); }
}
void EVALVisitor::visit(AssignStm* stm) { memoria[stm->id] = stm->e->accept(this); }
void EVALVisitor::visit(PrintStm* stm) { cout << stm->e->accept(this) << endl; }
void EVALVisitor::interprete(Program* program) {
    for (auto v: program->vlist) for (auto id: v->ids) memoria[id]=0;
    for (auto s: program->slist) s->accept(this);
}

 
int GencodeVisitor::visit(BinaryExp* exp) {
    switch(exp->op) {
        case PLUS_OP: {
            exp->left->accept(this);
            cout << "pushq %rax\n";
            exp->right->accept(this);
            cout << "movq %rax, %rcx\n";
            cout << "popq %rax\n";
            cout << "addq %rcx, %rax\n";
            break;
        }
        case LE_OP: {
            exp->left->accept(this);
            cout << "pushq %rax\n";
            exp->right->accept(this);
            cout << "movq %rax, %rcx\n";
            cout << "popq %rax\n";
            cout << "cmpq %rcx, %rax\n";
            cout << "movl $0, %eax\n";
            cout << "setl %al\n";
            cout << "movzbq %al, %rax\n";
            break;
        }
        case GT_OP: {
            exp->left->accept(this);
            cout << "pushq %rax\n";
            exp->right->accept(this);
            cout << "movq %rax, %rcx\n";
            cout << "popq %rax\n";
            cout << "cmpq %rcx, %rax\n";
            cout << "movl $0, %eax\n";
            cout << "setg %al\n";
            cout << "movzbq %al, %rax\n";
            break;
        }
        case EQ_OP: {
            exp->left->accept(this);
            cout << "pushq %rax\n";
            exp->right->accept(this);
            cout << "movq %rax, %rcx\n";
            cout << "popq %rax\n";
            cout << "cmpq %rcx, %rax\n";
            cout << "movl $0, %eax\n";
            cout << "sete %al\n";
            cout << "movzbq %al, %rax\n";
            break;
        }
        default: break;
    }
    return 0;
}
int GencodeVisitor::visit(NumberExp* exp) { cout << "movq $" << exp->value << ", %rax\n"; return 0; }
int GencodeVisitor::visit(IdExp* exp) { cout << "movq " << -8*env[exp->value] << "(%rbp), %rax\n"; return 0; }
void GencodeVisitor::visit(PrintStm* stm) { stm->e->accept(this); cout << "movq %rax, %rsi\n"; cout<<" leaq print_fmt(%rip), %rdi\n"; cout<<"movl $0, %eax\n"; cout<<"call printf@PLT\n"; }
void GencodeVisitor::visit(AssignStm* stm) { env[stm->id]=contador; stm->e->accept(this); cout << "movq %rax," << -8*contador << "(%rbp)\n"; contador++; }
void GencodeVisitor::visit(IfStm* stm) {
    int lbl = ++contador;
    stm->condicion->accept(this);
    cout << "cmpq $0, %rax\n";
    cout << "je else" << lbl << "\n";
    if (stm->thenBody) for (auto s: stm->thenBody->slist) s->accept(this);
    cout << "jmp endif" << lbl << "\n";
    cout << "else" << lbl << ":\n";
    if (stm->elseBody) for (auto s: stm->elseBody->slist) s->accept(this);
    cout << "endif" << lbl << ":\n";
}
void GencodeVisitor::visit(WhileStm* stm) {
    int lbl = ++contador;
    cout << "start" << lbl << ":\n";
    stm->condicion->accept(this);
    cout << "cmpq $0, %rax\n";
    cout << "je end" << lbl << "\n";
    if (stm->body) for (auto s: stm->body->slist) s->accept(this);
    cout << "jmp start" << lbl << "\n";
    cout << "end" << lbl << ":\n";
}

void GencodeVisitor::code(Program* program) {
    
    contador = 1;
    for (auto v: program->vlist) {
        for (auto id: v->ids) {
            env[id] = contador++;
        }
    }
    int totalVars = contador - 1;

    cout << ".data\n";
    cout << "print_fmt: .string \"%ld\\n\" " << "\n";
    cout << ".text\n";
    cout << ".globl main\n";
    cout << "main:\n";
    cout << "pushq %rbp\n";
    cout << "movq %rsp, %rbp\n";
    int alloc = 8 * (totalVars + 2);
    cout << "sub $" << alloc << ", %rsp\n";
    // statements
    for (auto s: program->slist) s->accept(this);
    cout << "movl $0, %eax\n";
    cout << "leave\n";
    cout << "ret\n";
    cout << ".section .note.GNU-stack,\"\",@progbits\n";
}

